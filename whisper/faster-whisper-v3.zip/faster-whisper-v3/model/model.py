import base64
import logging
import os
from tempfile import NamedTemporaryFile
from typing import Dict

import requests
import ctranslate2
import faster_whisper
from faster_whisper import WhisperModel
from faster_whisper.audio import decode_audio
from faster_whisper.vad import VadOptions, get_speech_timestamps

logger = logging.getLogger(__name__)

_NO_SPEECH_COEFF = -3.7054642362321193
_AVG_LOGPROB_COEFF = 0.04797854548053526
_BIAS = 1.0332079730313122
_COMPRESSION_RATIO_THRESHOLD = 2.4

MODEL_CACHE_PATH = "/app/model_cache/faster-whisper-large-v3"
SAMPLE_RATE = 16000
TEMPERATURE_FALLBACK = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    return float(raw)


def _env_float_or_none(name: str):
    raw = os.getenv(name)
    if raw is None or raw == "":
        return None
    return float(raw)


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    return int(raw)


def _is_segment_valid(
    no_speech_prob: float, avg_logprob: float, compression_ratio: float
) -> bool:
    speech_score = (
        _NO_SPEECH_COEFF * no_speech_prob
        + _AVG_LOGPROB_COEFF * avg_logprob
        + _BIAS
    )
    return speech_score > 0 and compression_ratio < _COMPRESSION_RATIO_THRESHOLD


def _as_bool(value, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)


class Model:
    def __init__(self, **kwargs) -> None:
        self._data_dir = kwargs["data_dir"]
        self._config = kwargs["config"]
        self._secrets = kwargs["secrets"]
        self._lazy_data_resolver = kwargs["lazy_data_resolver"]
        self._model = None

    def load(self):
        self._lazy_data_resolver.block_until_download_complete()

        model_repo = os.getenv("WHISPER_MODEL_REPO") or None
        if model_repo:
            from huggingface_hub import snapshot_download

            try:
                hf_token = self._secrets.get("hf_access_token")
            except Exception:
                hf_token = None
            logger.info(f"Downloading fine-tuned model from HF: {model_repo}")
            model_path = snapshot_download(model_repo, token=hf_token)
            logger.info(f"Model downloaded to: {model_path}")
        else:
            model_path = MODEL_CACHE_PATH
            logger.info(f"Using bundled model: {model_path}")

        self._model = WhisperModel(model_path, device="cuda", compute_type="float16")
        logger.info("WhisperModel loaded")

    def preprocess(self, request: Dict) -> Dict:
        audio_base64 = request.get("audio")
        url = request.get("url")

        if audio_base64 and url:
            return {
                "error": "Only a base64 audio file OR a URL can be passed to the API, not both."
            }
        if not audio_base64 and not url:
            return {
                "error": "Please provide either an audio file in base64 string format or a URL."
            }

        if audio_base64:
            binary_data = base64.b64decode(audio_base64)
        else:
            resp = requests.get(url)
            binary_data = resp.content

        passthrough = {
            "whisper_params": request.get("whisper_params"),
            "vad_parameters": request.get("vad_parameters"),
            "debug": request.get("debug"),
            "disable_segment_filter": request.get("disable_segment_filter"),
        }
        passthrough = {k: v for k, v in passthrough.items() if v is not None}
        return {"data": binary_data, **passthrough}

    def predict(self, request: Dict) -> Dict:
        if request.get("error"):
            return request

        audio_data = request.get("data")

        with NamedTemporaryFile(suffix=".wav") as fp:
            fp.write(audio_data)
            fp.flush()
            audio = decode_audio(fp.name, sampling_rate=SAMPLE_RATE)

        duration_s = len(audio) / SAMPLE_RATE

        req_params = request.get("whisper_params") or {}
        req_vad = request.get("vad_parameters") or {}
        debug_mode = _as_bool(request.get("debug"), default=False)
        disable_segment_filter = _as_bool(
            request.get("disable_segment_filter"), default=False
        )

        def _param(name: str, env_name: str, default):
            if name in req_params and req_params[name] is not None:
                return req_params[name]
            if isinstance(default, bool):
                return _as_bool(os.getenv(env_name), default)
            if isinstance(default, int):
                return _env_int(env_name, default)
            if isinstance(default, float):
                return _env_float(env_name, default)
            return os.getenv(env_name) if os.getenv(env_name) is not None else default

        # Keep faster-whisper defaults when no VAD overrides are provided.
        # We only pass vad_parameters when request/env explicitly asks for tuning.
        vad_parameters = {}
        if "threshold" in req_vad:
            vad_parameters["threshold"] = req_vad["threshold"]
        elif os.getenv("FW_VAD_THRESHOLD") not in (None, ""):
            vad_parameters["threshold"] = _env_float("FW_VAD_THRESHOLD", 0.5)

        if "neg_threshold" in req_vad:
            vad_parameters["neg_threshold"] = req_vad["neg_threshold"]
        elif os.getenv("FW_VAD_NEG_THRESHOLD") not in (None, ""):
            vad_parameters["neg_threshold"] = _env_float("FW_VAD_NEG_THRESHOLD", 0.35)

        if "min_speech_duration_ms" in req_vad:
            vad_parameters["min_speech_duration_ms"] = req_vad["min_speech_duration_ms"]
        elif os.getenv("FW_VAD_MIN_SPEECH_MS") not in (None, ""):
            vad_parameters["min_speech_duration_ms"] = _env_int("FW_VAD_MIN_SPEECH_MS", 0)

        if "max_speech_duration_s" in req_vad:
            vad_parameters["max_speech_duration_s"] = req_vad["max_speech_duration_s"]
        elif os.getenv("FW_VAD_MAX_SPEECH_S") not in (None, ""):
            vad_parameters["max_speech_duration_s"] = _env_float_or_none("FW_VAD_MAX_SPEECH_S")

        if "min_silence_duration_ms" in req_vad:
            vad_parameters["min_silence_duration_ms"] = req_vad["min_silence_duration_ms"]
        elif os.getenv("FW_VAD_MIN_SILENCE_MS") not in (None, ""):
            vad_parameters["min_silence_duration_ms"] = _env_int(
                "FW_VAD_MIN_SILENCE_MS", 2000
            )

        if "speech_pad_ms" in req_vad:
            vad_parameters["speech_pad_ms"] = req_vad["speech_pad_ms"]
        elif os.getenv("FW_VAD_SPEECH_PAD_MS") not in (None, ""):
            vad_parameters["speech_pad_ms"] = _env_int("FW_VAD_SPEECH_PAD_MS", 400)

        vad_parameters = {k: v for k, v in vad_parameters.items() if v is not None}
        logger.info(
            "Using vad_parameters=%s (%s)",
            vad_parameters,
            "override" if vad_parameters else "faster-whisper defaults",
        )

        temperature = req_params.get("temperature", TEMPERATURE_FALLBACK)
        if isinstance(temperature, (int, float)):
            temperature = [float(temperature)]

        transcribe_kwargs = {
            "audio": audio,
            "beam_size": int(_param("beam_size", "FW_BEAM_SIZE", 1)),
            "vad_filter": _as_bool(_param("vad_filter", "FW_VAD_FILTER", True), True),
            "word_timestamps": _as_bool(
                _param("word_timestamps", "FW_WORD_TIMESTAMPS", True), True
            ),
            "temperature": temperature,
            "compression_ratio_threshold": float(
                _param(
                    "compression_ratio_threshold",
                    "FW_COMPRESSION_RATIO_THRESHOLD",
                    2.4,
                )
            ),
            "log_prob_threshold": float(
                _param("log_prob_threshold", "FW_LOG_PROB_THRESHOLD", -1.0)
            ),
            "no_speech_threshold": float(
                _param("no_speech_threshold", "FW_NO_SPEECH_THRESHOLD", 0.6)
            ),
            "condition_on_previous_text": _as_bool(
                _param(
                    "condition_on_previous_text",
                    "FW_CONDITION_ON_PREVIOUS_TEXT",
                    True,
                ),
                True,
            ),
            "language": req_params.get("language"),
        }
        if vad_parameters:
            transcribe_kwargs["vad_parameters"] = vad_parameters

        segments, info = self._model.transcribe(**transcribe_kwargs)

        all_segments = list(segments)
        result_segments = []
        dropped_by_speech_score = 0
        dropped_by_compression = 0
        raw_segments_debug = []
        dropped_segments_debug = []

        for seg in all_segments:
            speech_score = (
                _NO_SPEECH_COEFF * seg.no_speech_prob
                + _AVG_LOGPROB_COEFF * seg.avg_logprob
                + _BIAS
            )
            seg_debug = {
                "start": seg.start,
                "end": seg.end,
                "text": seg.text,
                "no_speech_prob": seg.no_speech_prob,
                "avg_logprob": seg.avg_logprob,
                "compression_ratio": seg.compression_ratio,
                "speech_score": speech_score,
            }
            raw_segments_debug.append(seg_debug)

            valid = _is_segment_valid(
                seg.no_speech_prob, seg.avg_logprob, seg.compression_ratio
            )
            if not disable_segment_filter and not valid:
                if speech_score <= 0:
                    dropped_by_speech_score += 1
                if seg.compression_ratio >= _COMPRESSION_RATIO_THRESHOLD:
                    dropped_by_compression += 1
                dropped_segments_debug.append(seg_debug)
                continue
            result_segments.append(
                {
                    "text": seg.text,
                    "start": seg.start,
                    "end": seg.end,
                    "no_speech_prob": seg.no_speech_prob,
                    "avg_logprob": seg.avg_logprob,
                    "compression_ratio": seg.compression_ratio,
                    "words": [
                        {
                            "word": w.word,
                            "start": w.start,
                            "end": w.end,
                            "probability": w.probability,
                        }
                        for w in (seg.words or [])
                    ],
                }
            )

        logger.info(
            f"Transcribed {duration_s:.1f}s audio, "
            f"produced {len(result_segments)} segments "
            f"(raw={len(all_segments)}, filter_disabled={disable_segment_filter})"
        )

        response = {
            "language": info.language,
            "language_probability": info.language_probability,
            "duration": duration_s,
            "segments": result_segments,
        }
        if debug_mode:
            vad_windows = []
            vad_error = None
            try:
                vad_opts = VadOptions(**vad_parameters) if vad_parameters else VadOptions()
                vad_chunks = get_speech_timestamps(audio, vad_options=vad_opts)
                vad_windows = [
                    {
                        "start_s": c["start"] / SAMPLE_RATE,
                        "end_s": c["end"] / SAMPLE_RATE,
                        "duration_s": (c["end"] - c["start"]) / SAMPLE_RATE,
                    }
                    for c in vad_chunks
                ]
            except Exception as e:
                vad_error = str(e)

            response["debug"] = {
                "faster_whisper_version": faster_whisper.__version__,
                "ctranslate2_version": ctranslate2.__version__,
                "effective_params": {
                    "beam_size": int(_param("beam_size", "FW_BEAM_SIZE", 1)),
                    "vad_filter": _as_bool(
                        _param("vad_filter", "FW_VAD_FILTER", True), True
                    ),
                    "vad_parameters": vad_parameters,
                    "word_timestamps": _as_bool(
                        _param("word_timestamps", "FW_WORD_TIMESTAMPS", True), True
                    ),
                    "temperature": temperature,
                    "compression_ratio_threshold": float(
                        _param(
                            "compression_ratio_threshold",
                            "FW_COMPRESSION_RATIO_THRESHOLD",
                            2.4,
                        )
                    ),
                    "log_prob_threshold": float(
                        _param("log_prob_threshold", "FW_LOG_PROB_THRESHOLD", -1.0)
                    ),
                    "no_speech_threshold": float(
                        _param("no_speech_threshold", "FW_NO_SPEECH_THRESHOLD", 0.6)
                    ),
                    "condition_on_previous_text": _as_bool(
                        _param(
                            "condition_on_previous_text",
                            "FW_CONDITION_ON_PREVIOUS_TEXT",
                            True,
                        ),
                        True,
                    ),
                    "language": req_params.get("language"),
                    "disable_segment_filter": disable_segment_filter,
                },
                "segment_counts": {
                    "raw_count": len(all_segments),
                    "kept_count": len(result_segments),
                    "dropped_count": len(all_segments) - len(result_segments),
                    "dropped_by_speech_score": dropped_by_speech_score,
                    "dropped_by_compression": dropped_by_compression,
                },
                "vad_windows": vad_windows,
                "vad_window_count": len(vad_windows),
                "vad_error": vad_error,
                "raw_segments": raw_segments_debug,
                "dropped_segments": dropped_segments_debug,
            }

        return response
